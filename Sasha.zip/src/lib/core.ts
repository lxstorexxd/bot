import config from "../DB/config.json";

export { config };
