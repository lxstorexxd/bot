import * as scheduler from "simple-scheduler-task";

import Account from "./lib/account";
import config from "./DB/config.json";

const account = new Account(config.authorization);

new scheduler.Interval(async () => {
	await account.updateInfo();
	if (account.info.balance > account.info.reservMoney) {
		const randomSlave = account.generateRandomSlave();
		await randomSlave.buy();
		await randomSlave.buyFetter();
		await randomSlave.setJob();
	}
}, 30000);

new scheduler.Interval(async () => {
	await account.checkSlaves();
}, config.delay );

account.updateInfo().then(async () => {
	console.log("started");
	await account.checkSlaves();
});
